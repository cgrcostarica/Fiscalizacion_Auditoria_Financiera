##############
##   Sider   #
##############

sidebar <- dashboardSidebar(
  sidebarMenu(
    menuItem("Intro",tabName = "p1", icon = icon("chalkboard")),
    menuItem("Eval",tabName = "p2", icon = icon("ruler"))
    
  )
)