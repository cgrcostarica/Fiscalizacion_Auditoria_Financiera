############################
#   Contenido del ui       # 
############################


ui <- dashboardPage(skin = "blue",
                        header ,
                        sidebar,
                    body # ,
                 #   setBackgroundColor(
                 #     color = c("#F7FBFF", "#2171B5"),
                 #     gradient = c("linear", "radial"),
                 #     direction = c("bottom", "top", "right", "left"),
                 #     shinydashboard = TRUE
                 #    )
                    
) 