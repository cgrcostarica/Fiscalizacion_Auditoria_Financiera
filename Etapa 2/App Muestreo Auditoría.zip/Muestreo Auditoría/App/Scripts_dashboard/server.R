############################
#   Contenido del server   # 
############################

server <- function(input, output) {
  
  ####################################################
  #                      IMPORTAR                    #
  ####################################################
  
  ##############################
  #          Importar Datos    #
  ##############################
  
  # Data la volvemos un objeto reactivo 
  #  data ---> data()
  
  data <- reactive({
    inFile <- input$file1
    if (is.null(inFile)) {
      return(NULL)
    }
    read.csv(inFile$datapath)
  })
  
  
  # Histograma de una variable #
  
  output$variable_select <- renderUI({
    if (is.null(data())) {
      return(NULL)
    } else {
      selectInput("variable", "Elija una variable:", names(data()))
    }
  })
  
  output$histogram <- renderPlot({
    if (is.null(input$variable)) {
      return(NULL)
    }
    ggplot(data(), aes_string(input$variable)) + geom_histogram(binwidth = 10) + labs(title = paste("Distribución de", input$variable), x = input$variable, y = "Frecuencia")
  })
  
  ####################################################
  #                     Muestra                      #
  ####################################################
  
  #################################
  #    Cálculo tamaño muestra     #
  #################################
  
  output$SampleSize <- renderReactable({
    
    if (input$update) {
      
      stage1 <- planning(materiality = input$freq1, 
                         expected = input$freq2,
                         likelihood = input$distri, 
                         conf.level = input$freq3
      )
      
      sample_size <- data.frame(`Muestra` = stage1$n)
      reactable(sample_size)
      
    } else {
      NULL
    }
    
  })
  
  #################################
  #    Visualización de la tabla  #
  #################################
  
  
  output$sample  <- renderReactable({
    
    if (input$update) {
      
      stage1 <- planning(materiality = input$freq1, 
                         expected = input$freq2,
                         likelihood = input$distri, 
                         conf.level = input$freq3
      )
      
      stage2 <- selection(
        data = data(), 
        size = stage1,      #### Stage1 previous defined 
        units = "values", 
        values = input$variable,   #### Column from  data
        method = "random", start = 2
      )
      
      sample <- stage2[["sample"]]
      
      reactable(sample)
      
    } else {
      NULL
    }
    
  })
  
  
  ########################
  #  Datos Reactive      #
  ########################
  
  Muestra <- reactive({
    
    stage1 <- planning(materiality = input$freq1, 
                       expected = input$freq2,
                       likelihood = input$distri, 
                       conf.level = input$freq3
    )
    
    stage2 <- selection(
      data = data(), 
      size = stage1,      #### Stage1 previous defined 
      units = "values", 
      values = input$variable,   #### Column from  data
      method = "random", start = 2
    )
    
    sample <- stage2[["sample"]]
    sample
  })
  
  
  #################################
  #         Descargar muestra     #
  #################################
  
  observeEvent(input$show1, {
    
    showModal(modalDialog(
      title = "Descargar los datos ", br(),
      br(),
      downloadButton("download2.1",".csv file"),
      br(),
      br(),
      downloadButton("download2.2",".txt file"),
      footer = modalButton("Close"),
      easyClose = TRUE)
    )
    
  })
  
  output$download2.1 <- downloadHandler(
    
    
    filename = function() {
      paste("Muestra-", Sys.Date(), ".csv", sep="")
    },
    
    content = function(file) {
      write.csv(Muestra(), file)
    }
  )
  
  output$download2.2 <- downloadHandler(
    
    filename = function() {
      paste("Muestra-", Sys.Date(), ".txt", sep="")
    },
    content = function(file) {
      write.table(Muestra(), file)
    }
  )
  
  
  ###########################################
  #                Evaluación               #
  ###########################################
  
  data2 <- reactive({
    inFile <- input$file2
    if (is.null(inFile)) {
      return(NULL)
    }
    read.csv(inFile$datapath)
  })
  
  output$var1 <- renderUI({
    selectInput("select_var1", "Seleccione Variable 1:", names(data2()))
  })
  
  output$var2 <- renderUI({
    selectInput("select_var2", "Seleccione Variable 2:", names(data2()))
  })
  
  observeEvent(input$analizar, {
    output$plotCorrelation <- renderPlot({
      plot(data2()[,input$select_var1], data2()[,input$select_var2], 
           main=paste("Correlación entre", input$select_var1, "y", input$select_var2), 
           xlab=input$select_var1, ylab=input$select_var2)
    })
  })
  
  
  
  
  # Structura #
  
  
  observeEvent(input$analizar, {
    output$eval <- renderPrint({
      
      stage4 <- evaluation(
        materiality = 0.03, 
        method = "stringer",
        conf.level = 0.95, 
        data = data2(),
        values = input$select_var1,
        values.audit = input$select_var2
      )
      
      summary(stage4)
      
    })
  })
  
}