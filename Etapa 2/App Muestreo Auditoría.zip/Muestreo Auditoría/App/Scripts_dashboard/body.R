############################
#          body            # 
############################


body <- dashboardBody( 
  tabItems(    tabItem(tabName = "p1",
                       
                       
                       h1("Importar de los datos", align = "center"),
                       br(),
                       fileInput("file1", "Importar datos del muestreo",
                                 accept = c("text/csv",
                                            "text/comma-separated-values,text/plain",
                                            ".csv")),
                       br(),
                       br(),
                       uiOutput("variable_select"),
                       plotOutput("histogram"),
                       br(),
                       br(),
                       h1("Muestreo: tamaño y selección", align = "center"),
                       br(),
                       br(),
                       h2("Cálculo de tamaño de muestra"),
                       br(),
                       sliderInput("freq1",
                                   "Materialidad:",
                                   min = 0.01,  max = 0.99, value = 0.05),
                       sliderInput("freq2",
                                   "Esperado:",
                                   min = 0.01,  max = 0.99, value = 0.01), 
                       selectInput("distri", "Seleccione el nivel:",  
                                   list(`Tipo` = list("poisson",
                                                      "binomial", 
                                                      "hypergeometric"
                                   )
                                   )
                       ),
                       sliderInput("freq3",
                                   "Nivel de confianza:",
                                   min = 0.01,  max = 0.99, value = 0.95),
                       actionButton("update", "Calcular"),
                       hr(),
                       fluidRow(
                         box(
                           solidHeader = TRUE, 
                           width = 12,
                           reactableOutput("SampleSize")  
                         )
                       ),
                       br(),
                       br(),
                       fluidRow(
                         box(
                           solidHeader = TRUE, 
                           width = 12,
                           reactableOutput("sample")  
                         )
                       ),
                       
                       #################################
                       #         Descargar muestra     #
                       #################################
                       
                       h2("Descargar la muestra seleccionada"),
                       br(),
                       actionButton("show1", "Descargar archivo")
  ),
  
  tabItem(tabName = "p2",
          
          
          h1("Evalución de la auditoría.", align = "center"),
          br(),
          br(),
          h3("Seleccionar el archivo a evaluar."),
          fileInput("file2", "Importar datos para la evaluación del muestreo.",
                    accept = c("text/csv",
                               "text/comma-separated-values,text/plain",
                               ".csv")),
          h3("Seleccionar los parametros para la evaluación de los valores observados y auditados."),
          br(),
          sliderInput("freq20",
                      "Materialidad:",
                      min = 0.01,  max = 0.99, value = 0.05),
          selectInput("method", "Seleccione el método de evaluación:",  
                      list(`Tipo` = list( "poisson", 
                                          "binomial",
                                          "hypergeometric",
                                          "stringer.poisson",
                                          "stringer.binomial", 
                                          "stringer.hypergeometric",
                                          "stringer.meikle",
                                          "stringer.lta", 
                                          "stringer.pvz",
                                          "rohrbach", 
                                          "moment", 
                                          "coxsnell", 
                                          "mpu",
                                          "direct",
                                          "difference", 
                                          "quotient", 
                                          "regression"
                      )
                      )
          ),
          sliderInput("freq21",
                      "Nivel de confianza:",
                      min = 0.01,  max = 0.99, value = 0.95),
          
          uiOutput("var1"),
          uiOutput("var2"),
          br(),
          actionButton("analizar", "Analizar Correlación"),
          br(),
          br(),
          plotOutput("plotCorrelation"),
          br(),
          verbatimTextOutput("eval")
          
  )
  )
  
  
)